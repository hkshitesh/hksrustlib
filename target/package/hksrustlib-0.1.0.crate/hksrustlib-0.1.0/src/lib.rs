pub fn my_function()
{
    println!("Hello Rust! This is my own Standard Lib");
}